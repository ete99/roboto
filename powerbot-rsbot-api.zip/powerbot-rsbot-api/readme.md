Copyright (c) 2011 - 2018 Dequeue Ltd and its licensors.
Use of this code is subject to our [Terms and Conditions](http://www.powerbot.org/terms/#license).
By contributing code to this repository you are assigning all intellectual property rights including copyright to us.
