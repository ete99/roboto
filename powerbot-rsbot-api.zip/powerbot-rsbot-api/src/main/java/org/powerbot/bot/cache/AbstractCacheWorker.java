package org.powerbot.bot.cache;

public abstract class AbstractCacheWorker {

	public abstract Block getBlock(final int tree_index, final int block);
}
