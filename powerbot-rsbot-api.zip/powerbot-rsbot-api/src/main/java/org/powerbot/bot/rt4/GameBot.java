package org.powerbot.bot.rt4;

public interface GameBot {

}
