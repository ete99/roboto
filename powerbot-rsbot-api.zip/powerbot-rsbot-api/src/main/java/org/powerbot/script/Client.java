package org.powerbot.script;

/**
 * Client
 * A marker interface for the class containing all entry points to pertinent game data.
 */
public interface Client {
}
