/**
 */
package org.powerbot.script.rt6;
