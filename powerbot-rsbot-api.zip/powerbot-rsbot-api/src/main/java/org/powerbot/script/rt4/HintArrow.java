package org.powerbot.script.rt4;

/**
 * HintArrow
 */
public class HintArrow {
}
