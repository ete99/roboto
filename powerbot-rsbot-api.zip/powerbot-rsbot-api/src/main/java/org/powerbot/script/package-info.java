/**
 */
package org.powerbot.script;
