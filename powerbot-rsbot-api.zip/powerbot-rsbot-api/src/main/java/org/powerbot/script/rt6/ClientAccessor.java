package org.powerbot.script.rt6;

/**
 * ClientAccessor
 */
public abstract class ClientAccessor extends org.powerbot.script.ClientAccessor<ClientContext> {

	public ClientAccessor(final ClientContext ctx) {
		super(ctx);
	}
}
