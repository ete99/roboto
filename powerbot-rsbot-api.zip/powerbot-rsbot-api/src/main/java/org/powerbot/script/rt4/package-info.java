/**
 */
package org.powerbot.script.rt4;
