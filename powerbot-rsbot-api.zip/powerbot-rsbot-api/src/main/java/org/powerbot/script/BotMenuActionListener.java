package org.powerbot.script;

import java.awt.event.ActionListener;

/**
 * BotMenuActionListener
 * A listener for actions on the client options menu item.
 */
public interface BotMenuActionListener extends ActionListener {
}
